
import sys
import traceback
import arcpy
from arcpy import env
from arcpy.sa import *

try:
    
    
    arcpy.AddMessage('Detrend a Raster Surface Model by Euclidean Plane.')

    # Check out any necessary licenses
    arcpy.CheckOutExtension("3D")
    arcpy.CheckOutExtension("spatial")
    

    ##An inout surface of three non-colinnear points
    zpoints = arcpy.GetParameterAsText(0)
    ##The field in the point file that stores the z values 
    zvalues = arcpy.GetParameterAsText(1)    
    ##The surface model to detrend
    insurface = arcpy.GetParameterAsText(2)
    ##The output detrended surface
    detrendedsurface = arcpy.GetParameterAsText(3)
    
    
    #         Hardcoded paths for testing          #
    ##An inout surface of three non-colinnear points
    #zpoints = r'Z:\GISpublic\GerryG\Python3\DetrendingToolsForPy3\fubar.gdb\fubar'
    ##The field in the point file that stores the z values 
    #zvalues = 'z' 
    ##The surface model to detrend
    #insurface = r'I:\SurfaceModels\GreenLiDARSouthFork2017\Bare_Earth_Digital_Elevation_Models\Clipped_Bare_Earth\clbe_nooksack_ft_WaSPNt.tif'
    ##The output detrended surface
    #detrendedsurface = r'Z:\GISpublic\GerryG\Python3\DetrendingToolsForPy3\euc_trend.tif'
    
    #set variables
    arcpy.AddMessage('Setting environmental varialbles...')
    arcpy.env.extent = zpoints
    arcpy.env.snapRaster = insurface
    arcpy.env.cellSize = insurface
    env.cartographicCoordinateSystem = insurface
    
    
    arcpy.AddMessage('Creating Euclian plane.....')
    trend = Trend(zpoints, zvalues, cell_size = '', order="1", regression_type = 'LINEAR', out_rms_file ='')
    
    
    arcpy.AddMessage('Creating detrended surface...')
    outMinus = Minus(insurface, trend)
    outMinus.save(detrendedsurface)
    
    
    arcpy.AddMessage("Done without error!")
    
except arcpy.ExecuteError: 
    msgs = arcpy.GetMessages(2) 
    arcpy.AddError(msgs)  
    arcpy.AddMessage(msgs)
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    msgs = "ArcPy ERRORS:\n" + arcpy.GetMessages(2) + "\n"
    arcpy.AddError(pymsg)
    arcpy.AddError(msgs)
    arcpy.AddMessage(pymsg + "\n")
    arcpy.AddMessage(msgs)
