try:
    import sys, string, os, arcpy, string, math, traceback
    from arcpy import env
    from arcpy.sa import *
    
    workspace = arcpy.GetParameterAsText(0)
    centerline = arcpy.GetParameterAsText(1)
    densifyDistance = arcpy.GetParameterAsText(2)
    densifyMaxDeviation = arcpy.GetParameterAsText(3)
    densifyMaxAngle = arcpy.GetParameterAsText(4)
    theinputsurface = arcpy.GetParameterAsText(5)
    finalsurf = arcpy.GetParameterAsText(6)
    deleteTempData = arcpy.GetParameterAsText(7)
    #
    #workspace = r"E:\ScriptsToSell\DetrendingTools"
    #centerline = r"E:\ScriptsToSell\DetrendingTools\Centerline.shp"
    #densifyDistance = '50'
    #densifyMaxDeviation = '0.33'
    #densifyMaxAngle = '10'
    #theinputsurface = r"E:\ScriptsToSell\DetrendingTools\uppersfdemcav"
    #finalsurf= "finminvor"
    #deleteTempData = "false"
    
    if deleteTempData == "true":
        deleteTempData = True
    else:
        deleteTempData = False
    
    #set variables
    theinputsurface2 = Raster(theinputsurface)
    env.workspace = workspace
    env.extent = theinputsurface2.extent
    env.snapRaster = theinputsurface
    env.cellSize = theinputsurface2.meanCellHeight
    env.overwriteOutput = True
    #env.cartographicCoordinateSystem = theinputsurface2
    
    
    #finalsurf =  "finalsurf"
    centerline3d = "centerline3d.shp"
    centerline3dpoints = "centerline3dpoints.shp"
    centerline3dpointsvoronoi = "centerline3dpointsvoronoi.shp"
    voronoiras = "voronoiras"
    
    
    arcpy.SetProduct("ArcInfo")
    arcpy.CheckOutExtension("3D")
    arcpy.CheckOutExtension("spatial")
    
    arcpy.AddMessage('\nDetrend a Raster Surface Model by Transect Lines.')
    arcpy.AddMessage('Created by Two Bit Algorithms.')
    arcpy.AddMessage('Copyright 2011, Gerry Gabrisch/ngerry@gabrisch.us')
    
    
    arcpy.AddMessage("Densifying line...")
    arcpy.Densify_edit(centerline, "DISTANCE", densifyDistance, densifyMaxDeviation, densifyMaxAngle)
    
    arcpy.AddMessage("Converting line nodes to points...")
    arcpy.FeatureVerticesToPoints_management(centerline, centerline3dpoints, "ALL")
    
    
    
    # Process: Create Thiessen Polygons
    arcpy.CreateThiessenPolygons_analysis(centerline3dpoints, centerline3dpointsvoronoi, "ALL")
    desc = arcpy.Describe(centerline3dpointsvoronoi)
    objectid = desc.OIDFieldName
    ZonalSt_tran1 = ZonalStatistics(centerline3dpointsvoronoi, objectid, theinputsurface,"MINIMUM", "DATA")
    ZonalSt_tran1.save(workspace + "\\" + "ZonalSt_tran1")
    
    # Process: Minus
    arcpy.gp.Minus_sa(theinputsurface,ZonalSt_tran1,finalsurf)
    
    if deleteTempData:
        arcpy.AddMessage("Deleting temporary data...")
        arcpy.Delete_management(centerline3dpoints, "")
        arcpy.Delete_management(ZonalSt_tran1, "")

    
    arcpy.RefreshCatalog(workspace)
    arcpy.AddMessage("Done!")
    
except arcpy.ExecuteError: 
    msgs = arcpy.GetMessages(2) 
    arcpy.AddError(msgs)  
    arcpy.AddMessage(msgs)
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    msgs = "ArcPy ERRORS:\n" + arcpy.GetMessages(2) + "\n"
    arcpy.AddError(pymsg)
    arcpy.AddError(msgs)
    arcpy.AddMessage(pymsg + "\n")
    arcpy.AddMessage(msgs)

