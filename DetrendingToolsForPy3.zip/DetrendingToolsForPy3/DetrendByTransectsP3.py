try:
    import sys, string, os, arcpy, string, math, traceback
    from arcpy import env
    from arcpy.sa import *
    
    
    
    workspace = arcpy.GetParameterAsText(0)
    tinworkspace = arcpy.GetParameterAsText(1)
    transects = arcpy.GetParameterAsText(2)
    theinputsurface = arcpy.GetParameterAsText(3)
    finalsurf = arcpy.GetParameterAsText(4)
    deletetempdata = arcpy.GetParameterAsText(5)
    
    #workspace = r"Z:\GISpublic\GerryG\Darrell_problem\MT.gdb"
    #tinworkspace = r"Z:\GISpublic\GerryG\Darrell_problem"
    #transects = r"Z:\GISpublic\GerryG\Darrell_problem\LSF_REM.gdb\LSF_Transects_Project1"
    #theinputsurface = r"Z:\GISpublic\GerryG\Darrell_problem\LSF_REM.gdb\LSF_DEM"
    #finalsurf = r"Z:\GISpublic\GerryG\Darrell_problem\LSF_REM.gdb\DTR_DEM"
    #deletetempdata = "true"

    arcpy.env.overwriteOutput = True

    #set variables
    theinputsurface2 = Raster(theinputsurface)
    arcpy.env.workspace = workspace
    arcpy.env.extent = theinputsurface2.extent
    arcpy.env.snapRaster = theinputsurface
    arcpy.env.cellSize = theinputsurface2.meanCellHeight
    env.cartographicCoordinateSystem = theinputsurface 
    
    lines_Feature_Layer = "lines_Feature_Layer"
    floodsym = "floodsym"
    floodsymtin = tinworkspace + "/" + "floodsymtin"
    Output_Raster = "floodsymR"
    ZonalSt_tran1 = "ZonalSt_tran1"
    RasterT_ZonalSt1 = "RasterT_ZonalSt1"
    FinalOutput = "FinalOutput"
    cellsize = "CELLSIZE " + str(theinputsurface2.meanCellHeight)
    
    arcpy.SetProduct("ArcInfo")
    arcpy.CheckOutExtension("3D")
    arcpy.CheckOutExtension("Spatial")
    
    arcpy.AddMessage('\nDetrend a Raster Surface Model by Transect Lines.')
    arcpy.AddMessage('Created by Two-Bit Algorithms.')
    arcpy.AddMessage('Copyright 2015, Lummi Indian Business Council\nGerry Gabrisch\ngeraldg@lummi-nsn.gov')
    
    desc = arcpy.Describe(transects)
    objectid = desc.OIDFieldName
    arcpy.CreateFeatureclass_management(workspace, floodsym, "POINT", "", "DISABLED", "DISABLED", "", "", "0", "0", "0")
    arcpy.AddField_management(floodsym, "GRID_CODE", "DOUBLE", "", "", "", "", "", "", "")
    arcpy.AddMessage("All variables and arguments declared")
    arcpy.MakeFeatureLayer_management(transects, lines_Feature_Layer, "", "", "")
    
    
    
    arcpy.AddMessage("Selecting minimum values along transect lines...")
    ZonalSt_tran1 = ZonalStatistics(lines_Feature_Layer, objectid, theinputsurface2,"MINIMUM", "DATA")
    
    arcpy.AddMessage("Converting minimum values cells to points...")
    arcpy.RasterToPoint_conversion(ZonalSt_tran1, RasterT_ZonalSt1, "Value")
        
    arcpy.AddMessage("Creating empty TIN...")
    arcpy.CreateTin_3d(floodsymtin, "", "", "")
    
    arcpy.AddMessage("Building TIN...")
    arcpy.EditTin_3d(floodsymtin, "RasterT_ZonalSt1 GRID_CODE <None> masspoints false", "")
    
    arcpy.AddMessage("Converting TIN to raster...")
    arcpy.TinRaster_3d(floodsymtin, Output_Raster, "FLOAT", "LINEAR", cellsize, "1")

    arcpy.AddMessage("Detrending...")
    outMinus = Minus(theinputsurface, Output_Raster)
   
    arcpy.AddMessage("Saving final surface.........")
    outMinus.save(finalsurf)
    
    arcpy.AddMessage("Populating transects with z values...")
    arcpy.AddSurfaceInformation_3d(transects, floodsymtin, "Z_MIN")

    
    
    if deletetempdata == "true":
        
        arcpy.AddMessage("Deleting temporary data...")
        arcpy.Delete_management(floodsymtin, "")
        arcpy.Delete_management(Output_Raster, "")
        #arcpy.Delete_management(floodsym, "")
    
    

    arcpy.AddMessage("Done!")
    
except arcpy.ExecuteError: 
    msgs = arcpy.GetMessages(2) 
    arcpy.AddError(msgs)  
    arcpy.AddMessage(msgs)
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    msgs = "ArcPy ERRORS:\n" + arcpy.GetMessages(2) + "\n"
    arcpy.AddError(pymsg)
    arcpy.AddError(msgs)
    arcpy.AddMessage(pymsg + "\n")
    arcpy.AddMessage(msgs)


