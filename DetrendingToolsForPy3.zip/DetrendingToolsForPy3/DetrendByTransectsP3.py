try:
    import sys
    import arcpy
    import traceback
    from arcpy.sa import *

    arcpy.SetProduct("ArcInfo")
    arcpy.CheckOutExtension("3D")
    arcpy.CheckOutExtension("Spatial")

    
    workspace = arcpy.GetParameterAsText(0)
    tin = arcpy.GetParameterAsText(1)
    transects = arcpy.GetParameterAsText(2)
    theinputsurface = arcpy.GetParameterAsText(3)
    finalsurf = arcpy.GetParameterAsText(4)
    deletetempdata = arcpy.GetParameterAsText(5)
    

    
    #workspace = r"Z:\GISpublic\GerryG\OtherMapRequests\DetrendedDelta\foo.gdb"
    #tin = r"Z:\GISpublic\GerryG\OtherMapRequests\DetrendedDelta\tin"
    #transects = r"Z:\GISpublic\GerryG\OtherMapRequests\DetrendedDelta\foo.gdb\transects"
    #theinputsurface = r"I:\SurfaceModels\LiDAR_2022_Topobathymetric\BareEarth\topo_bathy_bare_earth_2022_WaSPN.tif"
    #finalsurf = r"Z:\GISpublic\GerryG\OtherMapRequests\DetrendedDelta\mydataDTR_DEM.tif"
    #deletetempdata = "false"

    arcpy.env.overwriteOutput = True
    arcpy.env.workspace = workspace
    arcpy.env.extent = theinputsurface
    arcpy.env.snapRaster = theinputsurface
    #arcpy.env.cellSize = theinputsurface
    arcpy.env.cartographicCoordinateSystem = theinputsurface 

    
    arcpy.AddMessage('\nRunning Detrend a Raster Surface Model by Transect Lines.')
    arcpy.AddMessage('Copyright 2023, Lummi Indian Business Council\nGerry Gabrisch  geraldg@lummi-nsn.gov')

    
    arcpy.AddMessage('Getting minimum surface elevations along transect lines...')
    arcpy.ddd.AddSurfaceInformation(transects, theinputsurface, "Z_MIN")
        
    arcpy.AddMessage("Creating TIN...")
   
    arcpy.ddd.CreateTin(tin, None, "transects Z_Min Soft_Line <None>", "DELAUNAY")
    
    arcpy.AddMessage("Converting TIN to raster...")
    #arcpy.ddd.TinRaster(tin, "tin_raster", "FLOAT", "LINEAR", "CELLSIZE", 1, 3)
    arcpy.ddd.TinRaster(in_tin=tin, out_raster='tin_raster', data_type="FLOAT", method="LINEAR", sample_distance="CELLSIZE", z_factor=1, sample_value=3)
    tin_raster = arcpy.Raster('tin_raster')

    arcpy.AddMessage("Detrending...")
    outMinus = Minus(theinputsurface,"tin_raster")
    arcpy.AddMessage("Saving final surface.........")
    outMinus.save(finalsurf)
    
    
    if deletetempdata == "true":
        
        arcpy.AddMessage("Deleting temporary data...")
        arcpy.Delete_management(tin, "")
        arcpy.Delete_management("tin_raster", "")


    arcpy.AddMessage("Finished without errors!")
    
except arcpy.ExecuteError: 
    msgs = arcpy.GetMessages(2) 
    arcpy.AddError(msgs)  
    arcpy.AddMessage(msgs)
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    msgs = "ArcPy ERRORS:\n" + arcpy.GetMessages(2) + "\n"
    arcpy.AddError(pymsg)
    arcpy.AddError(msgs)
    arcpy.AddMessage(pymsg + "\n")
    arcpy.AddMessage(msgs)


