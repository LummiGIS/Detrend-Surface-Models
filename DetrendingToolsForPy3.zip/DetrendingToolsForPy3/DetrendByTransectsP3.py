try:
    import sys
    import arcpy
    import traceback
    from arcpy.sa import *

    arcpy.SetProduct("ArcInfo")
    arcpy.CheckOutExtension("3D")
    arcpy.CheckOutExtension("Spatial")

    
    workspace = arcpy.GetParameterAsText(0)
    tin = arcpy.GetParameterAsText(1)
    transects = arcpy.GetParameterAsText(2)
    theinputsurface = arcpy.GetParameterAsText(3)
    finalsurf = arcpy.GetParameterAsText(4)
    deletetempdata = arcpy.GetParameterAsText(5)
    

    
    #workspace = r"Z:\GISpublic\GerryG\Restoration\detrend\detrend.gdb"
    #tin = r"Z:\GISpublic\GerryG\Restoration\detrend\tin"
    #transects = r"Z:\GISpublic\GerryG\Restoration\detrend\detrend.gdb\transects"
    #theinputsurface = r"I:\SurfaceModels\LiDAR_SFNR_Acme2024\DTM_acme2024Lidar.tif"
    #finalsurf = r"Z:\GISpublic\GerryG\Restoration\detrend\detrend1.tif"
    #deletetempdata = "true"

    arcpy.env.overwriteOutput = True
    arcpy.env.workspace = workspace
    arcpy.env.extent = theinputsurface
    arcpy.env.snapRaster = theinputsurface
    #arcpy.env.cellSize = theinputsurface
    arcpy.env.cartographicCoordinateSystem = theinputsurface 

    
    arcpy.AddMessage('\nRunning Detrend a Raster Surface Model by Transect Lines.')
    arcpy.AddMessage('Copyright 2023, Lummi Indian Business Council\nGerry Gabrisch  geraldg@lummi-nsn.gov')

    
    arcpy.AddMessage('Getting minimum surface elevations along transect lines...')
    arcpy.ddd.AddSurfaceInformation(transects, theinputsurface, "Z_MIN")
        
    arcpy.AddMessage("Creating TIN...")
   
    
    arcpy.ddd.CreateTin(out_tin=tin, spatial_reference="", in_features=[[transects, "Z_Min", "Soft_Line", "<None>"]])
    
    arcpy.AddMessage("Converting TIN to raster...")

    arcpy.ddd.TinRaster(in_tin=tin, out_raster='tin_raster', data_type="FLOAT", method="LINEAR", sample_distance="CELLSIZE", z_factor=1, sample_value=3)
    tin_raster = arcpy.Raster('tin_raster')

    arcpy.AddMessage("Detrending...")
    outMinus = Minus(theinputsurface,"tin_raster")
    arcpy.AddMessage("Saving final surface.........")
    outMinus.save(finalsurf)
    
    
    if deletetempdata == "true":
        
        arcpy.AddMessage("Deleting temporary data...")
        arcpy.Delete_management(tin, "")
        arcpy.Delete_management("tin_raster", "")


    arcpy.AddMessage("Finished without errors!")
    
except arcpy.ExecuteError:    
    arcpy.AddError(arcpy.GetMessages(2))    

# Return any other type of error
except:
    # By default any other errors will be caught here
    e = sys.exc_info()[1]
    print(e.args[0])
