
x= 5
print('foo')
print('bar')