try:
    import arcpy
    import sys
    import traceback
    from arcpy import env
    from arcpy.sa import *
    
    arcpy.AddMessage('\nDetrend a Raster Surface Model by Euclidean Plane.')
    arcpy.AddMessage('Another Two Bit Algorithms product.')
    arcpy.AddMessage('Copyright 2014, Lummi Nation, Gerry Gabrisch\ngeraldg@lummi-nsn.gov')
    
    # Check out any necessary licenses
    arcpy.CheckOutExtension("3D")
    arcpy.CheckOutExtension("spatial")
    
    # Script arguments
    zpoints = arcpy.GetParameterAsText(0)
    insurface = arcpy.GetParameterAsText(1)
    zvalues = arcpy.GetParameterAsText(2)
    trendsurface = arcpy.GetParameterAsText(3)
    polyorder =  arcpy.GetParameterAsText(4)
    detrendedsurface = arcpy.GetParameterAsText(5)
    
    if trendsurface == "":
        trendsurface = "trendsurface" 
    
    #set variables
    theinputsurface2 = Raster(insurface)
    arcpy.env.extent = theinputsurface2.extent
    arcpy.env.snapRaster = insurface
    arcpy.env.cellSize = theinputsurface2.meanCellHeight
    env.cartographicCoordinateSystem = insurface
    trendcellsize = str(theinputsurface2.meanCellHeight)

    
    arcpy.AddSurfaceInformation_3d(zpoints, insurface, zvalues, "BILINEAR", "", "1", "0", "NO_FILTER")
    
    arcpy.gp.Trend_sa(zpoints, zvalues, trendsurface, trendcellsize, polyorder, "LINEAR", "")
    
    arcpy.gp.Minus_sa(insurface, trendsurface, detrendedsurface)
    
    
    
    arcpy.AddMessage("Done without error!")
    
except arcpy.ExecuteError: 
    msgs = arcpy.GetMessages(2) 
    arcpy.AddError(msgs)  
    arcpy.AddMessage(msgs)
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    msgs = "ArcPy ERRORS:\n" + arcpy.GetMessages(2) + "\n"
    arcpy.AddError(pymsg)
    arcpy.AddError(msgs)
    arcpy.AddMessage(pymsg + "\n")
    arcpy.AddMessage(msgs)
